module.exports = {
	"extends": "wordpress",
};
